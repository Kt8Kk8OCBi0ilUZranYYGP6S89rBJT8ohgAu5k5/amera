
#include "menu_helpers.hpp"

#pragma once
class FontManager
{
public:
    ImFont* GetIconFont(ImGuiIO& io, float size);
};

