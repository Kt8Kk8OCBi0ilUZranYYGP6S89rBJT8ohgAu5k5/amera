
#include "RuntimeSaver.h"

RuntimeSaver g_Saver;