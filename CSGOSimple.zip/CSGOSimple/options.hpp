#pragma once

#include <string>
#include "valve_sdk/Misc/Color.hpp"

class Options {

};

extern bool g_Unload;
extern bool g_IsAllowed;